
/*--------------------------------------------------------------*/
/*PROGRAM PEMBELIAN TIKET KONSER KPOP 2017*/
/*--------------------------------------------------------------*/

#include <iostream>
#include <string.h>

using namespace std;
int main () 
{
	char nama[20],alamat[20],username[20],password[10];
	int pilih,tiket;
	long int uang,hasil,diskon,total_pembayaran;
	
	cout<<"SELAMAT DATANG DI LAYANAN TIKET HAPPY";
	cout<<"\n---------------------------------------------------------";
	cout<<"\nPembelian dilakukan dengan memenuhi syarat berikut : ";
	cout<<"\nnama	: ";
	cin.getline(nama,sizeof(nama));
	cout<<"\nalamat	: ";
	cin>>alamat;
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah anda ingin membeli tiket?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cin.ignore();
	cout<<"\nMasukan pilihan anda : ";
	cin>>pilih;
	switch(pilih){
	case 1:
	cout<<"\n---------------------------------------------------------";
	cout<<"\nAnda ingin membeli tiket apa?";			
	cout<<"\n1. GDRAGON";
	cout<<"\n2. EXO";
	cout<<"\n3. SHINEE";
	cout<<"\nMasukan pilihan tiket anda	: ";
	cin>>tiket;
	switch (tiket){
		case 1 :
			cout<<"\nDAFTAR TIKET GDragon ";
			cout<<"\n1. VIP IDR 1 RP 4.000.000";
			cout<<"\n2. VIP IDR 2 RP 3.000.000";
			cout<<"\n3. VIP IDR 3 RP 2.500.000";
			cout<<"\nPilih tiket	: ";
			cin>>tiket;
			switch(tiket){
			case 1:
			cout<<"\nAnda telah memesan tiket VIP IDR 1 RP 4.000.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=4000000){
				hasil=uang-4000000;
					if(hasil!=0){
					cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
					}
					else{
					cout<<"\nUang Anda pas\n";
					}
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih){
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";
	cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}
	}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}
}
			else {
			cout<<"\nUang tidak cukup\n";
			}
			break;
			case 2:
			cout<<"\nAnda memesan tiket VIP IDR 2 RP 3.000.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=3000000){
				hasil=uang-3000000;
				if(hasil!=0){
				cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
				}
				else{
				cout<<"\nUang Anda pas\n";
				}
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih){
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";
	cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}
}
			else {
			cout<<"\nUang tidak cukup\n";
			}
			break;
			case 3:
			cout<<"\nAnda memesan tiket VIP IDR 3 RP 2.500.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=2500000){
				hasil=uang-2500000;
				if(hasil!=0){
				cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
				}
				else{
				cout<<"\nUang Anda pas\n";
				}
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih)
	{
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";
	cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}
}
			else {
			cout<<"\nUang tidak cukup\n";
			}
			break;
			default:
			cout<<"\nMaaf tiket tidak tersedia\n";
			break;
			}
			break;
		case 2 :
		cout<<"\nDAFTAR TIKET EXO";
		cout<<"\n1. kelas A RP 2.5000.000";
		cout<<"\n2. kelas B RP 1.500.000";
		cout<<"\n3. kelas C RP 1.000.000";
		cout<<"\nPilih tiket	: ";
		cin>>tiket;
		switch(tiket){
		case 1:
			cout<<"\nAnda memesan tiket kelas A  RP 2.500.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=2500000){
			hasil=uang-2500000;
				if(hasil!=0){
				cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
				}
				else{
				cout<<"\nUang Anda pas\n";
				}
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih){
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";
	cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}
}
			else {
			cout<<"\nUang tidak cukup\n";
			}
		break;
		case 2:
			cout<<"\nAnda memesan tiket kelas B RP 1.500.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=1500000){
			hasil=uang-1500000;
				if(hasil!=0){
				cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
				}
				else{
				cout<<"\nUang Anda pas\n";
				}
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih){
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}}
			else {
			cout<<"\nUang tidak cukup\n";
			}
		break;
		case 3:
			cout<<"\nAnda memesan tiket kelas C RP 1.000.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=1000000){
			hasil=uang-1000000;
				if(hasil!=0){
				cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
				}
				else{
				cout<<"\nUang Anda pas\n";
				}
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih){
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";
	cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}
}
			else {
			cout<<"\nUang tidak cukup\n";
			}
		break;
		default:
		cout<<"\nTiket tidak ada\n";
		break;
		}							
		break;
		case 3 :
		cout<<"\nDAFTAR TIKET SHINEE";
		cout<<"\n1. GOLD RP 3.000.000\n";
		cout<<"\n2. SILVER RP 2.500.000\n";
		cout<<"\n3. YELLOW RP 1.500.000\n";
		cout<<"\nPilih tiket	: ";
		cin>>tiket;
		switch(tiket){
			case 1:
			cout<<"\nAnda memesan tiket GOLD RP 3.000.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=3000000){
			hasil=uang-3000000;
				if(hasil!=0){
				cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
				}
				else{
				cout<<"\nUang Anda pas\n";
				}
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih){
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";
	cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}
}
			else {
			cout<<"\nMaaf Uang tidak cukup\n";
			}
			break;
			case 2:
			cout<<"\nAnda memesan tiket SILVER RP 2.500.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=2500000){
			hasil=uang-2500000;
				if(hasil!=0){
				cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
				}
				else{
				cout<<"\nUang Anda pas\n";
				}
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih){
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}}
			else {
			cout<<"\nMaaf Uang tidak cukup\n";
			}
			break;
			case 3:
			cout<<"\nAnda memesan tiket YELLOW RP 1.500.000\n";
			cout<<"\nMasukkan uang Anda : ";
			cin>>uang;
			if(uang>=1500000){
			hasil=uang-1500000;
				if(hasil!=0){
				cout<<"\nKembalian uang Anda : Rp"<<hasil<<endl;
				}
				else{
				cout<<"\nUang Anda pas\n";
	cout<<"\n---------------------------------------------------------";
	cout<<"\nApakah Anda Termasuk Member ?";
	cout<<"\n1. YA";
	cout<<"\n2. TIDAK";
	cout<<"\njawaban pilihan : ";
	cin>>pilih;
	switch (pilih){
	case 1 :
	cout<<"\nUsername	: ";
	cin>>username;
	cout<<"password	: ";
	cin>>password;
	if (strcmp(username,"alivi")==0 && strcmp(password,"567")==0){
	cout<<"\nLogin SUKSES \n";
	cout<<"\nMasukkan total pembayaran uang Anda : ";
	cin>>uang;
	if(uang>=2000000){
	diskon=0.05*uang;
	total_pembayaran=uang-diskon;
	if(hasil!=0){
	cout<<"\nAnda mendapatkan diskon : Rp"<<diskon<<endl;
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}
	else{
	cout<<"\nanda tidak mendapat diskon\n";
	cout<<"TOTAL PEMBAYARAN ANDA ADALAH RP "<<total_pembayaran<<endl;
	cout<<"\nTERIMAKASIH\n";
	}}
	else {
	cout<<"\nanda tidak mendapat diskon\n";					
		}}
	if(strcmp(username,"alivi")!=0 && strcmp(password,"567")==0) 
	cout<<"\nusername tidak tersedia \n";
	else if(strcmp(username,"alivi")==0 && strcmp(password,"567")!=0) 
	cout<<"\npassword anda salah \n";
	break;
	case 2 :
	cout<<"\nApakah anda ingin mendaftar sebagai member ?";
	cout<<"\n1.YA";
	cout<<"\n2.TIDAK";
	cout<<"\npilihan : ";
	cin>>pilih;
		if(pilih==1){
		cout<<"\nusername : ";
		cin>>username;
		cout<<"\npassword : ";
		cin>>password;
		cout<<"\nAnda telah terdaftar dengan username "<<username<<"\n";
		cout<<"\npassword anda adalah "<<password<<"\n";
		cout<<"BELANJA LAGI DAN GUNAKAN KARTU MEMBER UNTUK MENDAPATKAN DISKON";
		cout<<"\nTERIMAKASIH\n";
		}
			else
			cout<<"\nTERIMAKASIH\n";
		break;
		default :
		cout<<"pilihan tidak tersedia ";
	}}}
			else {
			cout<<"\nMaaf Uang tidak cukup\n";
			}
			break;
			default:
			cout<<"\nTiket tidak ada\n";
			break;
			}
			break;
			default:
			cout<<"\ntiket tidak tersedia\n";			
			}
		break;
		case 2:
			cout<<"\nTerimakasih\n";
			break;
		default :
			cout<<"\npilihan yang Anda masukkan tidak ada\n";
	}
	return 0;

	}
